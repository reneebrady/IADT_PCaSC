% function TTP_Scatter

close all

AllPatients = [  1   4   6   7   8  11  12  13  14  15 ...
                16  17  18  19  20  24  25  26  28  29 ...
                30  31  33  36  37  39  40  41  42  44 ...
                48  49  50  52  54  55  58  60  61  62 ...
                63  66  71  73  75  77  78  79  80  81 ...
                84  86  87  88  90  91  93  94  95  96 ...
                97  99 100 101 102 104 105 106 108 109];
Ben    = [  1   8  11   12  13  18  19  20  25  26  36  39  49  50 ...
           55  60  71   73  75  79  90  91  93 102 109];
       
load TTP.mat
Bruch_TTP(:,2) = Bruch_TTP(:,2)/30;

%Bruchovsky
IND = find(Bruch_TTP(:,3) == 0); y_Resp = Bruch_TTP(IND,2); %Responsive
y_Resp(find(y_Resp > 120)) = 120;
IND = find(Bruch_TTP(:,3) == 2); y_Res  = Bruch_TTP(IND,2); %Resistant
IND = find(Bruch_TTP(:,3) == 1.5); y_AE  = Bruch_TTP(IND,2); %Adverse event or death

%Continuous ADT
IND = find(CADT_TTP(:,3) == 0); %Responsive
y2_Resp = CADT_TTP(IND,2)/30; y2_Resp(find(y2_Resp > 120)) = 120;
IND = find(CADT_TTP(:,3) == 2); %Resistant
y2_Res  = CADT_TTP(IND,2)/30; y2_Res = y2_Res(find(y2_Res <= 120));

%No Induction
IND = find(NoInd_TTP(:,3) == 0); %Responsive
y3_Resp = NoInd_TTP(IND,2)/30; y3_Resp(find(y3_Resp > 120)) = 120;
IND = find(NoInd_TTP(:,3) == 2); %Resistant
y3_Res  = NoInd_TTP(IND,2)/30; y3_Res = y3_Res(find(y3_Res <= 120));


Col = lines(2);
Col = [0.8 0.8 0.8; lines(1)];

figure(1); hold on
plotSpread(y_Resp,'distributionMarkers','o','distributionColors','k',...
    'MarkerFaceColor','w','MarkerEdgeColor','k','MarkerSize',16)
plotSpread(y_AE,'distributionMarkers','.','distributionColors','r',...
    'MarkerFaceColor','r','MarkerEdgeColor','r','MarkerSize',58)
plotSpread(y_Res,'distributionMarkers','.','distributionColors','k',...
    'MarkerFaceColor','k','MarkerEdgeColor','k','MarkerSize',58)

plotSpread({[],[],y2_Resp},'distributionMarkers','o','distributionColors',Col(1,:),...
    'MarkerFaceColor','w','MarkerEdgeColor',Col(1,:),'MarkerSize',16)
plotSpread({[],[],y2_Res},'distributionMarkers','.','distributionColors',Col(1,:),...
    'MarkerFaceColor',Col(1,:),'MarkerEdgeColor',Col(1,:),'MarkerSize',58)

plotSpread({[],[],[],[],y3_Resp},'distributionMarkers','o','distributionColors',Col(2,:),...
    'MarkerFaceColor','w','MarkerEdgeColor',Col(2,:),'MarkerSize',16)
plotSpread({[],[],[],[],y3_Res},'distributionMarkers','.','distributionColors',Col(2,:),...
    'MarkerFaceColor',Col(2,:),'MarkerEdgeColor',Col(2,:),'MarkerSize',58)

% xlab = {'IADT'; 'Cont.'; 'IADT'};
xlab = {'w/ Ind.^�'; 'ADT^�'; 'w/o Ind.^�'};
ylab = {'0'; '12'; '24'; '36'; '48'; '60'; '72'; '84'; '96'; '108'; 'EOS'};

figure(1); hold on
plot([0.5 1.5],[mean(y_Res) mean(y_Res)],'k-','linewidth',4)
plot([2.5 3.5],[mean(y2_Res) mean(y2_Res)],'-','Color',Col(1,:),'linewidth',4)
plot([4.5 5.5],[mean(y3_Res) mean(y3_Res)],'-','Color',Col(2,:),'linewidth',4)
set(gca,'yticklabel','')
set(gca,'ytick',[0:12:120],'yticklabel',ylab(:)) %16
set(gca,'xticklabel','')
set(gca,'xtick',[1 3 5],'xticklabel',xlab(:)) %16
set(gca,'fontsize',44) %60 
ylabel('Time to Progression (months)')
set(gcf, 'units','normalized','outerposition',[0 0 0.5 1])
print('../../Figures/Fig5/F_TTP_Scatter','-dpng')