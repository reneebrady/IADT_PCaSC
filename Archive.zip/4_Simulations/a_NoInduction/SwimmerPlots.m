close all

patients = [  1   4   6   7   8  11  12  13  14  15 ...
    16  17  18  19  20  24  25  26  28  29 ...
    30  31  33  36  37  39  40  41  42  44 ...
    48  49  50  52  54  55  58  60  61  62 ...
    63  66  71  73  75  77  78  79  80  81 ...
    84  86  87  88  90  91  93  94  95  96 ...
    97  99 100 101 102 104 105 106 108 109];
Res = zeros(109,1); 
Res([7 11 12 19 25 33 36 41 48 52 54 80  88  99 101 102]) = 2;
Res([6  8 16 18 20 42 49 71 73 78 84 94 102 109]) = 1;
Res([8 18 20 42 73 78 94 102 109]) = 1.5;

TI_Bruch = NaN(109,13); MAX = NaN(109,2);
for I = patients
    close all
    
    Chemo1 = []; Chemo2 = [];
    [PSAd,dayd,treatInt] = DataFix(I);
    TI_Bruch(I,1:length(treatInt)+1) = [I treatInt/30];
    MAX(I,:) = [I treatInt(end)];
end

IND = find(~isnan(MAX(:,2)));
MAX = MAX(IND,:); %TI_Bruch = TI_Bruch(IND,:);

[~,ind] = sort(MAX(:,2));
M = MAX(ind,:);

j = 1;
T_ON = zeros(70,1);
figure(1); hold on
for ii = 1:length(ind)
    i = M(ii,1);
    treatInt = TI_Bruch(i,2:end); treatInt = treatInt(~isnan(treatInt));
    for jj = 1:2:length(treatInt)-1
        fillyy([treatInt(jj) treatInt(jj+1)],[j j],[j+1 j+1],'r')
        T_ON(ii) = T_ON(ii) + treatInt(jj+1) - treatInt(jj);
    end
    for jj = 2:2:length(treatInt)-1
        fillyy([treatInt(jj) treatInt(jj+1)],[j j],[j+1 j+1],'k')
    end
    if Res(TI_Bruch(i,1)) == 1.5
        plot(treatInt(end),j+0.5,'s','Color','k',...
            'MarkerFaceColor','k','MarkerSize',10)
    elseif Res(TI_Bruch(i,1)) == 1
        plot(treatInt(end),j+0.5,'s','Color','k',...
            'MarkerFaceColor','w','MarkerSize',10)
    elseif Res(TI_Bruch(i,1)) == 2
        plot(treatInt(end),j+0.5,'<','Color',[0.5 0.5 0.5],...
            'MarkerFaceColor',[0.5 0.5 0.5],'MarkerSize',10)
    end
    j = j+2;
end

set(gca,'xtick',0:12:120) %16
yticks('')
ylim([0 141])
xlim([0 120])
ylabel('Patient')
xlabel('Months')
set(gca,'fontsize',50)
title('Bruchovsky Trial Data')
set(gcf, 'units','normalized','outerposition',[0 0 1 1]);
print('../../Figures/Fig5/A_Bruchovsky','-dpng')

load TTP.mat
TI_Bruch = TI_ConBruch;
j = 1;
T_ON_Bruch = [zeros(70,1) NaN(70,2)];
figure(2); hold on
for ii = 1:length(ind)
    i = M(ii,1);
    treatInt = TI_Bruch(i,2:end); treatInt = treatInt(~isnan(treatInt));
    for jj = 1:2:length(treatInt)-1
        fillyy([treatInt(jj) treatInt(jj+1)],[j j],[j+1 j+1],'r')
        T_ON_Bruch(ii,1) = T_ON_Bruch(ii,1) + treatInt(jj+1) - treatInt(jj);
    end
    for jj = 2:2:length(treatInt)-1
        fillyy([treatInt(jj) treatInt(jj+1)],[j j],[j+1 j+1],'k')
    end
    
    if Res(TI_Bruch(i,1)) == 1.5
        plot(treatInt(end),j+0.5,'s','Color','k',...
            'MarkerFaceColor','k','MarkerSize',10)
%     elseif Res(TI_Bruch(i,1)) == 1
%         plot(treatInt(end),j+0.5,'s','Color','k',...
%             'MarkerFaceColor','w','MarkerSize',10)
    elseif Res(TI_Bruch(i,1)) == 2
        plot(treatInt(end),j+0.5,'<','Color',[0.5 0.5 0.5],...
            'MarkerFaceColor',[0.5 0.5 0.5],'MarkerSize',10)
    end
    
    if Bruch_TTP(i,3) == 1
        plot(treatInt(end),j+0.5,'s','Color','k',...
            'MarkerFaceColor','k','MarkerSize',10)
    elseif Bruch_TTP(i,3) == 2
        plot(treatInt(end),j+0.5,'<','Color',[0.5 0.5 0.5],...
            'MarkerFaceColor',[0.5 0.5 0.5],'MarkerSize',10)
    end
    T_ON_Bruch(ii,2) = treatInt(end); 
    T_ON_Bruch(:,3) = T_ON_Bruch(:,1)./T_ON_Bruch(:,2);
    
    j = j+2;
end

set(gca,'xtick',0:12:120) %16
yticks('')
ylim([0 141])
xlim([0 120])
ylabel('Patient')
xlabel('Months')
set(gca,'fontsize',50)
title('Bruchovsky Trial; Extrapolated^�')
% title('IADT w/ Induction^�')
% title('Bruchovsky Trial Data')
set(gcf, 'units','normalized','outerposition',[0 0 1 1]);
print('../../Figures/Fig5/B_BruchovskyExtrapolated','-dpng')

%No Induction
load TTP.mat

MAX = NaN(109,2);
for I = patients
    treatInt = TI_NoInd(I,2:end); treatInt = treatInt(~isnan(treatInt));
    MAX(I,:) = [I treatInt(end)];
end

IND = find(~isnan(MAX(:,2)));
MAX = MAX(IND,:);

M = MAX(ind,:);

j = 1;
T_ON_NoInd = [zeros(70,1) NaN(70,2)];
figure(3); hold on
for ii = 1:length(ind)
    i = M(ii,1);
    treatInt = TI_NoInd(i,2:end); treatInt = treatInt(~isnan(treatInt));
    for jj = 1:2:length(treatInt)-1
        fillyy([treatInt(jj) treatInt(jj+1)],[j j],[j+1 j+1],'r')
        T_ON_NoInd(ii) = T_ON_NoInd(ii) + treatInt(jj+1) - treatInt(jj);
    end
    for jj = 2:2:length(treatInt)-1
        fillyy([treatInt(jj) treatInt(jj+1)],[j j],[j+1 j+1],'k')
    end
    if NoInd_TTP(i,3) == 1
        plot(treatInt(end),j+0.5,'s','Color','k',...
            'MarkerFaceColor','k','MarkerSize',10)
    elseif NoInd_TTP(i,3) == 2
        plot(treatInt(end),j+0.5,'<','Color',[0.5 0.5 0.5],...
            'MarkerFaceColor',[0.5 0.5 0.5],'MarkerSize',10)
    end
    T_ON_NoInd(ii,2) = treatInt(end); 
    T_ON_NoInd(:,3) = T_ON_NoInd(:,1)./T_ON_NoInd(:,2);
    
    j = j+2;
end

set(gca,'xtick',0:12:120) %16
yticks('')
ylim([0 141])
xlim([0 120])
ylabel('Patient')
xlabel('Months')
set(gca,'fontsize',50)
title('IADT w/o Induction^�')
set(gcf, 'units','normalized','outerposition',[0 0 1 1]);
print('../../Figures/Fig5/C_NoInduction','-dpng')

%No Induction
load TTP.mat

MAX = NaN(109,2);
for I = patients
    treatInt = [0 CADT_TTP(I,2)/30];
    MAX(I,:) = [I treatInt(end)];
end

IND = find(~isnan(MAX(:,2)));
MAX = MAX(IND,:);

M = MAX(ind,:);

j = 1;
T_ON_CADT = zeros(70,1);
figure(4); hold on
for ii = 1:length(ind)
    i = M(ii,1);
    treatInt = [0 CADT_TTP(i,2)/30];
    fillyy([treatInt(1) treatInt(2)],[j j],[j+1 j+1],'r')
    T_ON_CADT(ii) = treatInt(2) - treatInt(1);
    
    plot(treatInt(end),j+0.5,'<','Color',[0.5 0.5 0.5],...
        'MarkerFaceColor',[0.5 0.5 0.5],'MarkerSize',10)
    j = j+2;
end

set(gca,'xtick',0:12:120) %16
yticks('')
ylim([0 141])
xlim([0 120])
ylabel('Patient')
xlabel('Months')
set(gca,'fontsize',50)
title('Continuous ADT')
set(gcf, 'units','normalized','outerposition',[0 0 1 1]);
print('../../Figures/Fig5/D_ContinuousADT^�','-dpng')