function [PSAd,dayd,treatInt,treatmentOn] = DataFix(I)

dataAll = loadPatientData('patientdata-all');

datad = dataAll{I};

PSAd = datad(:,3);
dayd = datad(:,2);

treatmentOn = datad(:,6)>0;

PSAd(PSAd == 0) = NaN;

if I == 32
    dayd = dayd-dayd(1);
end

IND = find(~isnan(PSAd));
dayd = dayd(1:IND(end)); PSAd = PSAd(1:IND(end)); 
treatmentOn = treatmentOn(1:IND(end));

%Calculate treatment intervals
if (treatmentOn(1)==0)
    display('Warning: interval starts without treatment');
end

INDD1 = []; 
for ii = 1:length(treatmentOn)-1 
    if (treatmentOn(ii) == 1 && treatmentOn(ii+1) == 0) 
        INDD1 = [INDD1 ii+1];  
    end
end

treatInt = [0 dayd(INDD1)'];


INDD2 = []; 
for ii = 1:length(treatmentOn)-1
    if (treatmentOn(ii) == 0 && treatmentOn(ii+1) == 1)
        INDD2 = [INDD2 ii+1];
    end
end

treatInt = [treatInt dayd(INDD2)'];
treatInt = sort(treatInt);
if treatInt(end) ~= dayd(end)
    treatInt = [treatInt dayd(end)];
end

treatmentOn(INDD1) = ones(size(INDD1));
treatmentOn(INDD2) = zeros(size(INDD2));

IND = find(~isnan(PSAd)); PSAd = PSAd(IND); dayd = dayd(IND); treatmentOn = treatmentOn(IND);
%Needed for fits to testing data (checked clinical notes to justify)
if I == 8
    treatInt = treatInt(1:5);
elseif I == 14
    treatInt(4) = 1364;
elseif I == 24
    treatInt = treatInt(1:end-1);
elseif I == 31
    treatInt(2) = 336; treatInt = treatInt(1:end-1);
elseif I == 66
    treatInt(2) = 311; treatInt(4) = 1239;
elseif I == 94
    treatInt(2) = 449; treatInt = treatInt(1:end-1);
elseif I == 97
    treatInt = treatInt(1:end-1);
elseif I == 108
    treatInt = treatInt(1:end-1);
end