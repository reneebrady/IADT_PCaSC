%D1 and D2 should be nx2 matrices with the time to progression in the first
%column and whether or not the patient progressed in the second column (0 
%censored, 1 yes, 2 no)

function chi = LogRank(D1,D2)

%------------------------------------Log-Rank Test-------------------------
t = [0; D1(:,1); D2(:,1)]; t = unique(t); t = sort(t);
D = D1;
d = 0; 
for i = 2:length(t)
    num = length(find(D(:,1) == t(i) & D(:,2) == 2));
    d = [d; num];
end

c = 0; 
for i = 2:length(t)
    num = length(find(D(:,1) == t(i) & D(:,2) == 1)); 
    c = [c;num]; 
end
A1 = [t d c];

n = length(D(:,1));
for i = 2:length(t)
    n(i) = n(i-1)-sum(A1(i-1,2:3));
end
n = n';
A1 = [A1 n];

dn = 0; 
for i = 2:length(t)
    dn(i) = 1-A1(i,2)/A1(i,4); 
end
dn = dn';

S = 1; 
for i = 2:length(t)
    S(i) = S(i-1)*dn(i);
end
S = S';
A1 = [A1 dn S];

%--------------------------------Comparison group--------------------------
D = D2;
d = 0; 
for i = 2:length(t)
    num = length(find(D(:,1) == t(i) & D(:,2) == 2));
    d = [d;num];
end

c = 0; 
for i = 2:length(t)
    num = length(find(D(:,1) == t(i) & D(:,2) == 1)); 
    c = [c;num]; 
end
A2 = [t d c];

n = length(D(:,1));
for i = 2:length(t)
    n(i) = n(i-1)-sum(A2(i-1,2:3));
end
n = n';
A2 = [A2 n];

dn = 0; 
for i = 2:length(t)
    dn(i) = 1-A2(i,2)/A2(i,4); 
end
dn = dn';

S = 1; 
for i = 2:length(t)
    S(i) = S(i-1)*dn(i);
end
S = S';
A2 = [A2 dn S];

e1 = 0;
for i = 2:length(t)
    e1(i) = A1(i,4)*(A1(i,2)+A2(i,2))/(A1(i,4)+A2(i,4));
end
e1 = e1';
A1 = [A1 e1];

e2 = 0;
for i = 2:length(t)
    e2(i) = A2(i,4)*(A1(i,2)+A2(i,2))/(A1(i,4)+A2(i,4));
end
e2 = e2';
A2 = [A2 e2];

Ob1  = sum(A1(:,2)); Ob2  = sum(A2(:,2));
Exp1 = sum(A1(:,7)); Exp2 = sum(A2(:,7));

chi = (Ob1 - Exp1)^2/Exp1 + (Ob2 - Exp2)^2/Exp2;