close all

load PARS.mat

AllPatients = [  1   4   6   7   8  11  12  13  14  15 ...
    16  17  18  19  20  24  25  26  28  29 ...
    30  31  33  36  37  39  40  41  42  44 ...
    48  49  50  52  54  55  58  60  61  62 ...
    63  66  71  73  75  77  78  79  80  81 ...
    84  86  87  88  90  91  93  94  95  96 ...
    97  99 100 101 102 104 105 106 108 109];

Res = false(109,1); 
Res([7 11 12 19 25 33 36 41 48 52 54 80 88 99 101 102]) = true;

AE = false(109,1);
AE([8 18 20 42 73 78 94 102 109]) = true;

patients = AllPatients;

CR_TTP = [[1:1:109]' NaN(109,2)]; CN_TTP = [[1:1:109]' NaN(109,2)];
Bruch_TTP = [[1:1:109]' NaN(109,2)];

for I = patients
    close all
    
    Chemo1 = [];
    [PSAd,dayd,treatInt] = DataFix(I);
    
    %---------------------Castration Resistant DOC Sims--------------------
    Init = PARS(1:4,I); pars = PARS(5:15,I);
    pars(6) = 0.0027; pars(7) = 0.008;
    
    Init(3) = PSAd(1);
    
    sol.x = treatInt(1); sol.y = Init;
    
    if Res(I) || AE(I)
        sol = FittoData(pars,sol,treatInt,true);
        
%         TI_ConBruch(I,1:length(treatInt)+1) = [I treatInt/30];

        if AE(I)
            Bruch_TTP(I,2:3) = [sol.x(end) 1.5];
        else
            Bruch_TTP(I,2:3) = [sol.x(end) 2];
        end
        
    else
        sol = FittoData(pars,sol,treatInt,false);

        n = length(treatInt);
        if mod(n,2) == 0
            tx = 1;
        else
            tx = 0;
        end

        [sol,flag] = Bruchovsky(sol,pars,tx);

        if flag == 1
            Bruch_TTP(I,2:3) = [sol.x(end) 2];
        else
            Bruch_TTP(I,2:3) = [sol.x(end) 0];
        end
    end
    
%     sol = FittoData(pars,sol,treatInt);
% 
%     n = length(treatInt);
%     if mod(n,2) == 0
%         tx = 1;
%     else
%         tx = 0;
%     end
%     
%     [sol,flag] = Bruchovsky(sol,pars,tx);
%     
%     if flag == 1
%         B_TTP(I,2:3) = [sol.x(end) 2];
%         CR_TTP(I,2:3) = [sol.x(end) 2];
%     else
%         B_TTP(I,2:3) = [sol.x(end) 0];
%         CR_TTP(I,2:3) = [sol.x(end) 0];
%     end
    
    %-------------------------Induction DOC Sims---------------------------
    Init = PARS(1:4,I); pars = PARS(5:15,I);
    pars(6) = 0.0027; pars(7) = 0.008;
    
    Init(3) = PSAd(1);
    
    sol2.x = 0; sol2.y = Init;
    
    Chemo2 = sol2.x(end);
    [sol2,flag] = Chemo(pars,sol2,6);
    Chemo2 = [Chemo2 sol2.x(end)];
    
    if flag == 0
        [sol2,flag] = Bruchovsky2(sol2,pars);
    end
    
    if flag == 1
        CN_TTP(I,2:3) = [sol2.x(end) 2];
    else
        CN_TTP(I,2:3) = [sol2.x(end) 0];
    end
    
    Col = lines(2);
    
    figure(I); hold on;
    plot(dayd/30,PSAd,'bx','linewidth',30,'MarkerSize',48)
    plot(sol.x/30,sol.y(3,:),'k-','linewidth',8);
    plot(sol2.x/30,sol2.y(3,:),'-','Color',Col(1,:),'linewidth',8);
    ylabel('PSA (\mug/L)');
    set(gca,'xtick',0:12:120)
    xlim([0 max([sol.x(end)/30 sol2.x(end)/30])])
    if I < 10
        title(['Patient 00' num2str(I)])
    elseif I < 100
        title(['Patient 0' num2str(I)])
    else
        title(['Patient ' num2str(I)])
    end
    set(gca,'fontsize',46)
    ax = gca;
    if ~isempty(Chemo1)
        fillyy([Chemo1(1)/30 Chemo1(end)/30],[0 0],[ax.YLim(2) ax.YLim(2)],[0.8500    0.3250    0.0980])
        alpha(0.5)
    end
    if I == 36
        fillyy([Chemo2(1)/30 Chemo2(end)/30],[0 0],[25 25],[0    0.4470    0.7410])
    else
        fillyy([Chemo2(1)/30 Chemo2(end)/30],[0 0],[ax.YLim(2) ax.YLim(2)],[0    0.4470    0.7410])
    end
    alpha(0.5)
    set(gcf, 'units','normalized','outerposition',[0 0 1 1]);
    if I == 36
        print(['../../Figures/Fig7/C_DOCSim_p' int2str(I)],'-dpng')
    elseif I == 24
        print(['../../Figures/Fig7/D_DOCSim_p' int2str(I)],'-dpng')
    else
        print(['figures/DOCSim_p' int2str(I)],'-dpng')
    end
    
    figure(I+100); hold on;
    plot(sol.x/30,sol.y(1,:),'k-','linewidth',8);
    plot(sol2.x/30,sol2.y(1,:),'-','Color',Col(1,:),'linewidth',8);
    set(gca,'xtick',0:12:120)
    xlim([0 max([sol.x(end)/30 sol2.x(end)/30])])
    ylabel('PCaSC');
    xlabel('months');
    set(gca,'fontsize',46)
    ax = gca;
    if ~isempty(Chemo1)
        fillyy([Chemo1(1)/30 Chemo1(end)/30],[0 0],[ax.YLim(2) ax.YLim(2)],[0.8500    0.3250    0.0980])
        alpha(0.5)
    end
    fillyy([Chemo2(1)/30 Chemo2(end)/30],[0 0],[ax.YLim(2) ax.YLim(2)],[0    0.4470    0.7410])
    alpha(0.5)
    set(gca,'YScale','log')
    set(gcf, 'units','normalized','outerposition',[0 0 1 0.75]);
    if I == 36
        print(['../../Figures/Fig7/C_DOCSim_p' int2str(I) '_CSC'],'-dpng')
    elseif I == 24
        print(['../../Figures/Fig7/D_DOCSim_p' int2str(I) '_CSC'],'-dpng')
    else
        print(['figures/DOCSim_p' int2str(I) '_CSC'],'-dpng')
    end
end

% save TTP.mat Bruch_TTP CN_TTP
