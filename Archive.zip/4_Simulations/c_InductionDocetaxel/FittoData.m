function sol = FittoData(pars,sol,treatInt,all)

options = odeset('RelTol',1e-8,'AbsTol',1e-8); 
Init = sol.y(:,end); 
pars(9) = 0;

if all
    for ii = 2:length(treatInt)
        pars(8) = (1-mod(ii,2));

        solTmp = ode45(@modelBasic,[treatInt(ii-1) treatInt(ii)],Init,options,pars);
        sol.x  = [sol.x solTmp.x(2:end)];
        sol.y  = [sol.y solTmp.y(:,2:end)];

        Init = sol.y(:,end);

    end
else
    for ii = 2:length(treatInt)-1
        pars(8) = (1-mod(ii,2));

        solTmp = ode45(@modelBasic,[treatInt(ii-1) treatInt(ii)],Init,options,pars);
        sol.x  = [sol.x solTmp.x(2:end)];
        sol.y  = [sol.y solTmp.y(:,2:end)];

        Init = sol.y(:,end);

    end
end