function PlotTTP

close all

load TTP.mat

AllPatients = [  1   4   6   7   8  11  12  13  14  15 ...
                16  17  18  19  20  24  25  26  28  29 ...
                30  31  33  36  37  39  40  41  42  44 ...
                48  49  50  52  54  55  58  60  61  62 ...
                63  66  71  73  75  77  78  79  80  81 ...
                84  86  87  88  90  91  93  94  95  96 ...
                97  99 100 101 102 104 105 106 108 109];
            
Bruch_TTP = Bruch_TTP(AllPatients,:); %Bruch_TTP(:,2) = Bruch_TTP(:,2)/30; 
CN_TTP = CN_TTP(AllPatients,:); %CN_TTP(:,2) = CN_TTP(:,2)/30;
IND = find(Bruch_TTP(:,2) > 3650); Bruch_TTP(IND,2) = 3600;
IND = find(CN_TTP(:,2) > 3650); CN_TTP(IND,2) = 3600;

Col = lines(2);

x = 0:124;
figure(1); hold on
% fill([0 120 120 115.8 0],[0 0 120 120 4.2],'r'); alpha(0.2)
h = fill([0 115.8 0],[4.2 120 120],'g'); alpha(0.2)
set(h,'EdgeColor','none')
% fill([4.2 120 120],[0 0 115.8],'r'); alpha(0.2)
% plot(x,x,'--','linewidth',4,'Color',[0.7 0.7 0.7])
plot(Bruch_TTP(:,2)/30,CN_TTP(:,2)/30,'ko','MarkerFaceColor','k','MarkerSize',16)
% for i = 1:length(Bruch_TTP(:,2))
%     if CN_TTP(i,2) - Bruch_TTP(i,2) < 126
%         plot(Bruch_TTP(i,2)/30,CN_TTP(i,2)/30,'ko','MarkerFaceColor','k','MarkerSize',16)
%     else
%         plot(Bruch_TTP(i,2)/30,CN_TTP(i,2)/30,'o','Color',Col(1,:),'MarkerFaceColor',Col(1,:),'MarkerSize',16)
%     end
% end
xlabel({'IADT Alone^� TTP (months)'})
ylabel({'IADT w/ DOC^� TTP (months)'})
xlim([0 120])
ylim([0 120])
set(gca,'fontsize',36)
set(gca,'xtick',0:24:120)
set(gca,'ytick',0:12:120)
set(gcf, 'units','normalized','outerposition',[0 0 0.5 1])
print('../../Figures/Fig7/B_TTP_Compare','-dpng')