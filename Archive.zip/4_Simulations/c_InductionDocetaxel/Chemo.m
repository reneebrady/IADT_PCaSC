function [sol,flag] = Chemo(pars,sol,cycnum)

Init = sol.y(:,end);

pars(9) = 1; %DOC on
pars(8) = 1; %ADT on

options = odeset('RelTol',1e-8,'AbsTol',1e-8);

flag = 0; PSAnad = sol.y(3,end);

cyc = 1;

while cyc <= cycnum && sol.x(end) < 3650
    
    Init = [Init(1)*.98 Init(2)*.90 Init(3) Init(4)]'; %reduce CSC by 2% and CC by 10%                                            
                                                       %(DU145 line from Jaworska paper)

    sol.x = [sol.x sol.x(end)];
    sol.y = [sol.y Init];

    solTmp = ode45(@modelBasic,[sol.x(end) sol.x(end) + 21],Init,options,pars);
    sol.x  = [sol.x solTmp.x(2:end)];
    sol.y  = [sol.y solTmp.y(:,2:end)];

    Init = sol.y(:,end);

    %if PSA levels have doubled since beginning chemo, chemo is failing
    if flag == 0 && (solTmp.y(3,end) > 2*PSAnad) && solTmp.y(3,end)>2
        disp(['treatment failed -- PSA doubled during chemo'])
        flag = 1;
    end 

    cyc = cyc + 1;
end