function [sol,flag] = Bruchovsky(sol,pars,tx)

options = odeset('RelTol',1e-8,'AbsTol',1e-8);

flag = 0; Init = sol.y(:,end);

pars(9) = 0; %DOC off

% %Induction
% while sol.x(end) <= 36*7
%     solTmp = ode45(@modelBasic,[sol.x(end) sol.x(end)+28],Init,options,pars);
%     sol.x  = [sol.x solTmp.x(2:end)];
%     sol.y  = [sol.y solTmp.y(:,2:end)]; 
% 
%     Init = sol.y(:,end);
% end
% if flag < 1
%     IND1 = min(find(sol.x >= 168)); %find where Tx has been on for 24 weeks (168 days)
%     IND2 = min(find(sol.x >= 224)); %find where Tx has been on for 32 weeks (224 days)
% 
%     if ~isempty(IND1) && ~isempty(IND2) && (sol.y(3,IND1) > 4 && sol.y(3,IND2) > 4)
%         flag = 1;
%     end
% end
% % while sol.x(end) < 3650 && flag == 0
%     %---------------------------------Tx OFF-------------------------------
%     while sol.y(3,end) < 10 && sol.x(end) < 3650
%         pars(8) = 0;
%         solTmp = ode45(@modelBasic,[sol.x(end) sol.x(end)+28],Init,options,pars);
%         sol.x  = [sol.x solTmp.x(2:end)];
%         sol.y  = [sol.y solTmp.y(:,2:end)];
% 
%         Init = sol.y(:,end);
%     end
% % end
% % 

if tx == 1
%-------------------------------Start with Tx ON---------------------------
while sol.x(end) < 3650 && flag < 1
    %--------------------------------Tx ON---------------------------------
    pars(8) = 1; Tx_on = 0; beg_Tx = sol.x(end);
    while Tx_on < 36*7 && flag < 1 && sol.x(end) < 3650
        solTmp = ode45(@modelBasic,[sol.x(end) sol.x(end)+28],Init,options,pars);
        sol.x  = [sol.x solTmp.x(2:end)];
        sol.y  = [sol.y solTmp.y(:,2:end)];

        %if PSA levels are rising during Tx, then Tx is failing
        if sol.y(3,end) > 4 && (solTmp.y(3,end) - solTmp.y(3,2) > 0.25)
            flag = flag + (1/3); 
            if flag == 1
                break
            end
        end
        
        Init = sol.y(:,end);
        Tx_on = Tx_on + 28; 

    end
    IND1 = min(find(sol.x >= beg_Tx + 168)); %find where Tx has been on for 24 weeks (168 days)
    IND2 = min(find(sol.x >= beg_Tx + 224)); %find where Tx has been on for 32 weeks (224 days)
    if ~isempty(IND1) && ~isempty(IND2) && (sol.y(3,IND1) > 4 && sol.y(3,IND2) > 4)
        flag = 1;
        break
    end
    
    if flag == 0 && sol.x(end) < 3650
        %-----------------------------Tx OFF-------------------------------
        pars(8) = 0;
        while sol.y(3,end) < 10 && sol.x(end) < 3650
            solTmp = ode45(@modelBasic,[sol.x(end) sol.x(end)+28],Init,options,pars);
            sol.x  = [sol.x solTmp.x(2:end)];
            sol.y  = [sol.y solTmp.y(:,2:end)];

            Init = sol.y(:,end);
        end
    end
end
elseif tx == 0
%------------------------------Start with Tx OFF---------------------------
    while sol.x(end) < 3650 && flag < 1
        %-----------------------------Tx OFF-------------------------------
        pars(8) = 0;
        while sol.y(3,end) < 10 && sol.x(end) < 3650
            solTmp = ode45(@modelBasic,[sol.x(end) sol.x(end)+28],Init,options,pars);
            sol.x  = [sol.x solTmp.x(2:end)];
            sol.y  = [sol.y solTmp.y(:,2:end)];

            Init = sol.y(:,end);
        end

        %------------------------------Tx ON-------------------------------
        pars(8) = 1; Tx_on = 0; beg_Tx = sol.x(end);
        while Tx_on < 36*7 && flag < 1 && sol.x(end) < 3650
            solTmp = ode45(@modelBasic,[sol.x(end) sol.x(end)+28],Init,options,pars);
            sol.x  = [sol.x solTmp.x(2:end)];
            sol.y  = [sol.y solTmp.y(:,2:end)];

            %if PSA levels are rising during Tx, then Tx is failing
            if sol.y(3,end) > 4 && (solTmp.y(3,end) - solTmp.y(3,2) > 0.25)
                flag = flag + (1/3); 
                if flag == 1
                    break
                end
            end

            Init = sol.y(:,end);
            Tx_on = Tx_on + 28; 
        
        end
        IND1 = min(find(sol.x >= beg_Tx + 168)); %find where Tx has been on for 24 weeks (168 days)
        IND2 = min(find(sol.x >= beg_Tx + 224)); %find where Tx has been on for 32 weeks (224 days)
        if ~isempty(IND1) && ~isempty(IND2) && (sol.y(3,IND1) > 4 && sol.y(3,IND2) > 4)
            flag = 1;
            break
        end
    end
end
