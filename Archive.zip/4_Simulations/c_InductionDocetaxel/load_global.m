function [pars,Init,low,hi] = load_global

global ODE_TOL
ODE_TOL = 1e-8;

%-------------------------------Parameters---------------------------------
ps    = 1e-6;   lambda = log(2); gamma  = 1.2836; epsln = 0; 
alpha = 0.07;   deltas = 0.0027;   deltad = 0.008;   txa   = 1; 
txd   = 1;      varphi = 0.01;   rho    = 0.0001;
deltas = 0.01;   deltad = 0.03;
%----------------------------Initial Conditions----------------------------
S_I = 10; D_I = 1000; P_I = 29; DOC_I = 0;

Init = [S_I D_I P_I DOC_I];
    
%Parameter vector
pars = [ps lambda gamma epsln alpha deltas deltad txa txd varphi rho]'; %1-11

low = zeros(size(pars)); 
hi  = ones(size(pars)); %ps cannot be larger than 1

end

