function [sol,flag] = ContinuousADT(pars,sol)

Init = sol.y(:,end);
flag = 0;

options = odeset('RelTol',1e-8,'AbsTol',1e-8);

pars(8) = 1; pars(9) = 0;

while sol.x(end) < 3650 && flag < 1
    solTmp = ode45(@modelBasic,[sol.x(end) sol.x(end)+28],Init,options,pars);
    sol.x  = [sol.x solTmp.x(2:end)];
    sol.y  = [sol.y solTmp.y(:,2:end)];

    %if PSA levels are rising during Tx, then Tx is failing
    if sol.y(3,end) > 4 && (solTmp.y(3,end) - solTmp.y(3,2) > 0.25)
        flag = flag + (1/3); 
        if flag == 1
            break
        end
    end

    Init = sol.y(:,end);
end