function xdot = modelBasic(t,y,pars)

%States
S   = y(1);
D   = y(2);
P   = y(3);
DOC = y(4);

%Parameters
ps     = pars(1); lambda = pars(2);  gamma  = pars(3); epsln  = pars(4);  
alpha  = pars(5); deltas = pars(6);  deltad = pars(7); txa    = pars(8); 
txd    = pars(9); varphi = pars(10); rho    = pars(11);

%Equations
dS   = (S/(S+D))*ps*lambda*S - deltas*txd*S;
dD   = (1 - (S/(S+D))*ps)*lambda*S - alpha*txa*D - deltad*txd*D; 
dP   = -varphi*P + rho*D;
dDOC = 0;

xdot = [dS; dD; dP; dDOC];