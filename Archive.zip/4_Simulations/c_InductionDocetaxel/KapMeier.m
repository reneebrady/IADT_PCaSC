% function KapMeier

close all

AllPatients = [  1   4   6   7   8  11  12  13  14  15 ...
                16  17  18  19  20  24  25  26  28  29 ...
                30  31  33  36  37  39  40  41  42  44 ...
                48  49  50  52  54  55  58  60  61  62 ...
                63  66  71  73  75  77  78  79  80  81 ...
                84  86  87  88  90  91  93  94  95  96 ...
                97  99 100 101 102 104 105 106 108 109];

Res = zeros(109,1);
Res([7  11  12	19  25  33  36	41	48  52  54	80	88  99 101]) = 2; %Resistant
Res([6   8  16  18  20  42  49  71  73  78  84  94 102 109]) = 1; %Lost to followup

patients = AllPatients;

load TTP.mat
Bruchovsky_TTP = Bruch_TTP(patients,:);
Bruchovsky_TTP(:,2) = Bruchovsky_TTP(:,2)/30;

[~,IND] = sort(Bruchovsky_TTP(:,2),'ascend');
TTP = Bruchovsky_TTP(IND,:);
N = length(TTP);

IND = find(TTP(:,3) > 0); %find where patient was resistant or LTF
KM = TTP(IND,2); KM = unique(KM);
cKM = []; ctime = [];
S = 1;

D1 = TTP(:,2:3);

for i = 1:length(KM)
    RES = length(find(TTP(:,2) == KM(i) & TTP(:,3) == 2)); %find where TTP = day & patient was resistant
    LTF = length(find(TTP(:,2) == KM(i) & TTP(:,3) == 1.5)); %find where TTP = day & patient was LTF

    if LTF > 0
        cKM = [cKM; S(end)];
        ctime = [ctime; KM(i)];
    end
    
    S = [S; (1 - (RES/N))*S(end)];
    N = N - (RES + LTF);
    
end

dtime = 0;
for i = 1:length(KM)
    dtime = [dtime; KM(i); KM(i)];
end
dtime = [dtime; TTP(end,2)];

S2 = [];
for i = 1:length(S)
    S2 = [S2; S(i); S(i)];
end

figure(1); hold on; 
plot(dtime,S2,'k','linewidth',6)
plot(ctime,cKM,'r+','MarkerSize',12,'linewidth',6)
ylim([0 1])
set(gca,'xtick',0:12:120) %16
ylabel('Progression Free Survival')
xlabel('Time to Progression (months)')
set(gca,'fontsize',36)

load TTP.mat
%------------------------------CN_TTP--------------------------------------
CN_TTP = CN_TTP(patients,:);
CN_TTP(:,2) = CN_TTP(:,2)/30;
[~,IND] = sort(CN_TTP(:,2),'ascend');
TTP = CN_TTP(IND,:);
N = length(TTP);

IND = find(TTP(:,3) > 0); %find where patient was resistant or LTF
KM = TTP(IND,2); KM = unique(KM);
cKM = []; ctime = [];
S = 1;

D3 = TTP(:,2:3);

for i = 1:length(KM)
    RES = length(find(TTP(:,2) == KM(i) & TTP(:,3) == 2)); %find where TTP = day & patient was resistant
    LTF = length(find(TTP(:,2) == KM(i) & TTP(:,3) == 1)); %find where TTP = day & patient was LTF

    if LTF > 0
        cKM = [cKM; S(end)];
        ctime = [ctime; KM(i)];
    end
    
    S = [S; (1 - (RES/N))*S(end)];
    N = N - (RES + LTF);
    
end

dtime = 0;
for i = 1:length(KM)
    dtime = [dtime; KM(i); KM(i)];
end
dtime = [dtime; TTP(end,2)];

S2 = [];
for i = 1:length(S)
    S2 = [S2; S(i); S(i)];
end

Col = lines(2); 

figure(1); hold on; 
plot(dtime,S2,'Color',Col(1,:),'linewidth',6) %castration naive (blue)
plot(ctime,cKM,'r+','MarkerSize',12,'linewidth',6)
xlim([0 120]); ylim([0 1])
set(gcf, 'units','normalized','outerposition',[0 0 1 1]);
print('../../Figures/Fig7/A_KapMeier','-dpng')

chi_13 = LogRank(D1,D3);