function data = loadPatientData( folder )

    %get the list of files in the directory
    filelist = dir([folder '/*.txt']);

    data = cell(10,1);
    
    for cnt = 1 : length(filelist)
        patientNo = filelist(cnt).name(2:end-4);
        tmp = csvread([folder '/' filelist(cnt).name],1);
        data(str2double(patientNo)) = {tmp};
    end

end

