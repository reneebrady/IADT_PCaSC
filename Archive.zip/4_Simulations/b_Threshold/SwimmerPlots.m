close all

patients = [  1   4   6   7   8  11  12  13  14  15 ...
    16  17  18  19  20  24  25  26  28  29 ...
    30  31  33  36  37  39  40  41  42  44 ...
    48  49  50  52  54  55  58  60  61  62 ...
    63  66  71  73  75  77  78  79  80  81 ...
    84  86  87  88  90  91  93  94  95  96 ...
    97  99 100 101 102 104 105 106 108 109];
Res = zeros(109,1); 
Res([7 11 12 19 25 33 36 41 48 52 54 80  88  99 101 102]) = 2;
Res([6  8 16 18 20 42 49 71 73 78 84 94 102 109]) = 1;
Res([8 18 20 42 73 78 94 102 109]) = 1.5;

%90% Threshold
load TTP_Threshold.mat

MAX = NaN(109,2);
for I = patients
    treatInt = TI_Thres10(I,2:end); treatInt = treatInt(~isnan(treatInt));
    MAX(I,:) = [I treatInt(end)];
end

IND = find(~isnan(MAX(:,2)));
MAX = MAX(IND,:);

M = MAX(ind,:);

j = 1;
T_ON_10 = [zeros(70,1) NaN(70,2)];
figure(5); hold on
for ii = 1:length(ind)
    i = M(ii,1);
    treatInt = TI_Thres10(i,2:end); treatInt = treatInt(~isnan(treatInt));
    for jj = 1:2:length(treatInt)-1
        fillyy([treatInt(jj) treatInt(jj+1)],[j j],[j+1 j+1],'r')
        T_ON_10(ii,1) = T_ON_10(ii) + treatInt(jj+1) - treatInt(jj);
    end
    for jj = 2:2:length(treatInt)-1
        fillyy([treatInt(jj) treatInt(jj+1)],[j j],[j+1 j+1],'k')
    end
    if Threshold_TTP(i,7) == 1
        plot(treatInt(end),j+0.5,'s','Color','k',...
            'MarkerFaceColor','k','MarkerSize',10)
    elseif Threshold_TTP(i,7) == 2
        plot(treatInt(end),j+0.5,'<','Color',[0.5 0.5 0.5],...
            'MarkerFaceColor',[0.5 0.5 0.5],'MarkerSize',10)
    end
    T_ON_10(ii,2) = treatInt(end);
    j = j+2;
end
T_ON_10(:,3) = T_ON_10(:,1)./T_ON_10(:,2);

set(gca,'xtick',0:12:120) %16
yticks('')
ylim([0 141])
ylabel('Patient')
xlabel('Months')
set(gca,'fontsize',50)
xlim([0 120])
title('90% PSA Decline^�')
set(gcf, 'units','normalized','outerposition',[0 0 1 1]);
print('../../Figures/Fig6/C_Thres90','-dpng')

%50% Threshold
load TTP_Threshold.mat

MAX = NaN(109,2);
for I = patients
    treatInt = TI_Thres50(I,2:end); treatInt = treatInt(~isnan(treatInt));
    MAX(I,:) = [I treatInt(end)];
end

IND = find(~isnan(MAX(:,2)));
MAX = MAX(IND,:);

M = MAX(ind,:);

j = 1;
T_ON_50 = [zeros(70,1) NaN(70,2)];
figure(6); hold on
for ii = 1:length(ind)
    i = M(ii,1);
    treatInt = TI_Thres50(i,2:end); treatInt = treatInt(~isnan(treatInt));
    for jj = 1:2:length(treatInt)-1
        fillyy([treatInt(jj) treatInt(jj+1)],[j j],[j+1 j+1],'r')
        T_ON_50(ii) = T_ON_50(ii) + treatInt(jj+1) - treatInt(jj);
    end
    for jj = 2:2:length(treatInt)-1
        fillyy([treatInt(jj) treatInt(jj+1)],[j j],[j+1 j+1],'k')
    end
    if Threshold_TTP(i,5) == 1
        plot(treatInt(end),j+0.5,'s','Color','k',...
            'MarkerFaceColor','k','MarkerSize',10)
    elseif Threshold_TTP(i,5) == 2
        plot(treatInt(end),j+0.5,'<','Color',[0.5 0.5 0.5],...
            'MarkerFaceColor',[0.5 0.5 0.5],'MarkerSize',10)
    end
    T_ON_50(ii,2) = treatInt(end); 
    T_ON_50(:,3) = T_ON_50(:,1)./T_ON_50(:,2);
    
    j = j+2;
end

set(gca,'xtick',0:12:120) %16
yticks('')
ylim([0 141])
ylabel('Patient')
xlabel('Months')
set(gca,'fontsize',50)
xlim([0 120])
title('50% PSA Decline^�')
set(gcf, 'units','normalized','outerposition',[0 0 1 1]);
print('../../Figures/Fig6/B_Thres50','-dpng')

%30% Threshold
load TTP_Threshold.mat

MAX = NaN(109,2);
for I = patients
    treatInt = TI_Thres70(I,2:end); treatInt = treatInt(~isnan(treatInt));
    MAX(I,:) = [I treatInt(end)];
end

IND = find(~isnan(MAX(:,2)));
MAX = MAX(IND,:);

M = MAX(ind,:);

j = 1;
T_ON_70 = [zeros(70,1) NaN(70,2)];
figure(7); hold on
for ii = 1:length(ind)
    i = M(ii,1);
    treatInt = TI_Thres70(i,2:end); treatInt = treatInt(~isnan(treatInt));
    for jj = 1:2:length(treatInt)-1
        fillyy([treatInt(jj) treatInt(jj+1)],[j j],[j+1 j+1],'r')
        T_ON_70(ii) = T_ON_70(ii) + treatInt(jj+1) - treatInt(jj);
    end
    for jj = 2:2:length(treatInt)-1
        fillyy([treatInt(jj) treatInt(jj+1)],[j j],[j+1 j+1],'k')
    end
    if Threshold_TTP(i,3) == 1
        plot(treatInt(end),j+0.5,'s','Color','k',...
            'MarkerFaceColor','k','MarkerSize',10)
    elseif Threshold_TTP(i,3) == 2
        plot(treatInt(end),j+0.5,'<','Color',[0.5 0.5 0.5],...
            'MarkerFaceColor',[0.5 0.5 0.5],'MarkerSize',10)
    end
    T_ON_70(ii,2) = treatInt(end); 
    T_ON_70(:,3) = T_ON_70(:,1)./T_ON_70(:,2);
    
    j = j+2;
end

set(gca,'xtick',0:12:120) %16
yticks('')
ylim([0 141])
ylabel('Patient')
xlabel('Months')
set(gca,'fontsize',50)
xlim([0 120])
title('30% PSA Decline^�')
set(gcf, 'units','normalized','outerposition',[0 0 1 1]);
print('../../Figures/Fig6/A_Thres30','-dpng')