% close all

load PARS.mat

AllPatients = [  1   4   6   7   8  11  12  13  14  15 ...
    16  17  18  19  20  24  25  26  28  29 ...
    30  31  33  36  37  39  40  41  42  44 ...
    48  49  50  52  54  55  58  60  61  62 ...
    63  66  71  73  75  77  78  79  80  81 ...
    84  86  87  88  90  91  93  94  95  96 ...
    97  99 100 101 102 104 105 106 108 109];

Res = false(109,1); 
Res([7 11 12 19 25 33 36 41 48 52 54 80 88 99 101 102]) = true;

AE = false(109,1);
AE([8 18 20 42 73 78 94 102 109]) = true;

patients = AllPatients;

Threshold_TTP = [[1:1:109]' NaN(109,2) NaN(109,2) NaN(109,2)]; Bruch_TTP = [[1:1:109]' NaN(109,2)];
CADT_TTP = [[1:1:109]' NaN(109,2)];

TI_Thres10 = NaN(109,37); TI_Thres50 = NaN(109,33); TI_Thres70 = NaN(109,41); 

for I = patients
    close all
    
    Chemo1 = []; Chemo2 = [];
    [PSAd,dayd,treatInt] = DataFix(I);
    
    %------------------------Continue Bruchovsky---------------------------
    Init = PARS(1:4,I); pars = PARS(5:15,I);
    pars(6) = 0.0027; pars(7) = 0.008;
    
    Init(3) = PSAd(1);
    
    sol.x = treatInt(1); sol.y = Init;
    
    if Res(I) || AE(I)
        sol = FittoData(pars,sol,treatInt,true);
        
%         TI_ConBruch(I,1:length(treatInt)+1) = [I treatInt/30];

        if AE(I)
            Bruch_TTP(I,2:3) = [sol.x(end) 1.5];
        else
            Bruch_TTP(I,2:3) = [sol.x(end) 2];
        end
        
    else
        sol = FittoData(pars,sol,treatInt,false);

        n = length(treatInt);
        if mod(n,2) == 0
            tx = 1;
        else
            tx = 0;
        end

        [sol,flag,treatInt_new] = Bruchovsky(sol,pars,tx);
        treatInt_new = [treatInt_new sol.x(end)];

        treatInt = [treatInt(1:end-1) treatInt_new(2:end)];
        TI_ConBruch(I,1:length(treatInt)+1) = [I treatInt/30];

        if flag == 1
            Bruch_TTP(I,2:3) = [sol.x(end) 2];
        else
            Bruch_TTP(I,2:3) = [sol.x(end) 0];
        end
    end
    
%     sol = FittoData(pars,sol,treatInt);
% 
%     n = length(treatInt);
%     if mod(n,2) == 0
%         tx = 1;
%     else
%         tx = 0;
%     end
%     
%     [sol,flag,treatInt_new] = Bruchovsky(sol,pars,tx);
%     treatInt_new = [treatInt_new sol.x(end)];
%     
%     treatInt = [treatInt treatInt_new(2:end)];
%     
%     if flag == 1
%         Bruch_TTP(I,2:3) = [sol.x(end) 2];
%     else
%         Bruch_TTP(I,2:3) = [sol.x(end) 0];
%     end
    
    figure(I); hold on;
    plot(sol.x/30,sol.y(3,:),'k-','linewidth',12);
    plot(dayd/30,PSAd,'bx','linewidth',30,'MarkerSize',48)
    ylabel('PSA (\mug/L)');
    xlabel('months');
%     if I < 10
%         title(['Patient 00' num2str(I)])
%     elseif I < 100
%         title(['Patient 0' num2str(I)])
%     else
%         title(['Patient ' num2str(I)])
%     end
    set(gca,'fontsize',70)
    
    figure(I+100); hold on;
    plot(sol.x/30,sol.y(1,:),'k-','linewidth',12);
    ylabel('PCaSC');
    xlabel('months');
    set(gca,'fontsize',70)
    
    Col = lines(7);
    Col = Col([1 5 7],:);
    ii = 1;
    
    for thres = [0.7 0.5 0.1]
        %---------------------Threshold Sims--------------------
        Init = PARS(1:4,I); pars = PARS(5:15,I);

        Init(3) = PSAd(1);

        sol2.x = 0; sol2.y = Init;

        [sol2,flag,treatInt2] = Bruchovsky2(sol2,pars,thres);
        treatInt2 = [treatInt2 sol2.x(end)];

        if thres == 0.7
            TI_Thres70(I,1:length(treatInt2)+1) = [I treatInt2/30];
        elseif thres == 0.5
            TI_Thres50(I,1:length(treatInt2)+1) = [I treatInt2/30];
        elseif thres == 0.1
            TI_Thres10(I,1:length(treatInt2)+1) = [I treatInt2/30];
        end
        if flag == 1
            Threshold_TTP(I,2*ii:2*ii+1) = [sol2.x(end) 2];
        else
            Threshold_TTP(I,2*ii:2*ii+1) = [sol2.x(end) 0];
        end
        
        figure(I); hold on;
        plot(sol2.x/30,sol2.y(3,:),'-','Color',Col(ii,:),'linewidth',12);
        
        figure(I+100); hold on;
        plot(sol2.x/30,sol2.y(1,:),'-','Color',Col(ii,:),'linewidth',12);
        
        ii = ii+1;
    end
   
    figure(I); hold on; 
    xlim([0 3650/30])
    set(gcf, 'units','normalized','outerposition',[0 0 1 1]);
    if I == 54
        print(['../../Figures/Fig6/F_ThresholdSim_p' int2str(I)],'-dpng')
    else
        print(['figures/ThresholdSim_p' int2str(I)],'-dpng')
    end
    
    figure(I+100); hold on;
    xlim([0 3650/30])
    set(gca,'YScale','log')
    set(gcf, 'units','normalized','outerposition',[0 0 1 1]);
    if I == 54
        print(['../../Figures/Fig6/F_ThresholdSim_p' int2str(I) '_CSC'],'-dpng')
    else
        print(['figures/ThresholdSim_p' int2str(I) '_CSC'],'-dpng')
    end
end

% save TTP.mat CADT_TTP NoInd_TTP TI_ConBruch TI_NoInd Bruch_TTP