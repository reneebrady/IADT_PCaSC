function [y1,y2,CoV] = boxplot_BenvNoBen

close all

AllPatients = [  1   4   6   7   8  11  12  13  14  15 ...
                16  17  18  19  20  24  25  26  28  29 ...
                30  31  33  36  37  39  40  41  42  44 ...
                48  49  50  52  54  55  58  60  61  62 ...
                63  66  71  73  75  77  78  79  80  81 ...
                84  86  87  88  90  91  93  94  95  96 ...
                97  99 100 101 102 104 105 106 108 109];

NoBen = [  1   4   6   8  13  14  16  17  18  19  24  25  29  31  37 ...
          39  40  41  42  44  61  66  77  81  87  88  93  94  95  96 ...
          97  99 101 102 104 108];
Ben  =  [  7  11  12  15  20  26  28  30  33  36  48  49  50  52  54 ...
          55  58  60  62  63  71  73  75  78  79  80  84  86  90  91 ...
         100 105 106 109];

%Load parameters
load PARS.mat

y1 = PARS_0to1(5,NoBen); %Responsive
y2 = PARS_0to1(5,Ben); %Resistant

ii = -1;
NoBen = size(y1,2);
if (isempty(y1) || length(y1)<3)
    ii = ii + 2;
    h(2) = plot(0,0,'r-');
    COV(2) = NaN;
else
    for i = 1:size(y1,1)
        ii = ii + 2;
        x = sort(y1(i,:));

        COV(2) = std(x)/mean(x)*100;

        Q2 = median(x);

        I  = 0.25*(NoBen+1);
        II = floor(I);
        if I - II == 0
            Q1 = x(II);
        else
            Q1 = x(II) + (I - II)*(x(II+1)-x(II));
        end

        I  = 0.75*(NoBen+1);
        II = floor(I);
        if I - II == 0
            Q3 = x(II);
        else
            Q3 = x(II) + (I - II)*(x(II+1)-x(II));
        end
    
        IQR = Q3 - Q1;

        UIF = Q3 + 1.5*IQR;
        LIF = Q1 - 1.5*IQR;

        UIF = min(UIF,max(x));   
        LIF = max(LIF,min(x));

        figure(1); hold on
        h = plot([ii-0.5 ii+0.5],[Q2 Q2],'Color',[0.25 0.25 0.25],'linewidth',6);
        h = rectangle('Position',[ii-0.5 Q1 1 IQR],'EdgeColor',[0.25 0.25 0.25],'linewidth',6);
        h = plot([ii ii],[Q3 UIF],'--','Color',[0.25 0.25 0.25],'linewidth',6);
        h = plot([ii-0.5 ii+0.5],[UIF UIF],'Color',[0.25 0.25 0.25],'linewidth',6);
        h = plot([ii ii],[Q1 LIF],'--','Color',[0.25 0.25 0.25],'linewidth',6);
        h = plot([ii-0.5 ii+0.5],[LIF LIF],'Color',[0.25 0.25 0.25],'linewidth',6);
    end
end

NoBen = size(y2,2);
if (isempty(y2) || length(y2)<3)
    ii = ii + 2;
    h(2) = plot(0,0,'r-');
    COV(2) = NaN;
else
    for i = 1:size(y2,1)
        ii = ii + 2;
        x = sort(y2(i,:));

        COV(2) = std(x)/mean(x)*100;

        Q2 = median(x);

        I  = 0.25*(NoBen+1);
        II = floor(I);
        if I - II == 0
            Q1 = x(II);
        else
            Q1 = x(II) + (I - II)*(x(II+1)-x(II));
        end

        I  = 0.75*(NoBen+1);
        II = floor(I);
        if I - II == 0
            Q3 = x(II);
        else
            Q3 = x(II) + (I - II)*(x(II+1)-x(II));
        end
    
        IQR = Q3 - Q1;

        UIF = Q3 + 1.5*IQR;
        LIF = Q1 - 1.5*IQR;

        UIF = min(UIF,max(x));   
        LIF = max(LIF,min(x));

        figure(1); hold on
        h = plot([ii-0.5 ii+0.5],[Q2 Q2],'Color',[0.25 0.25 0.25],'linewidth',6);
        h = rectangle('Position',[ii-0.5 Q1 1 IQR],'EdgeColor',[0.25 0.25 0.25],'linewidth',6);
        h = plot([ii ii],[Q3 UIF],'--','Color',[0.25 0.25 0.25],'linewidth',6);
        h = plot([ii-0.5 ii+0.5],[UIF UIF],'Color',[0.25 0.25 0.25],'linewidth',6);
        h = plot([ii ii],[Q1 LIF],'--','Color',[0.25 0.25 0.25],'linewidth',6);
        h = plot([ii-0.5 ii+0.5],[LIF LIF],'Color',[0.25 0.25 0.25],'linewidth',6);
    end
end

y1 = y1'; y2 = y2';
CoV = std([y1;y2])/mean([y1;y2]);

Col = lines(2);

plotSpread(y1,'distributionMarkers','.','distributionColors','k',...
    'MarkerFaceColor','k','MarkerEdgeColor','k','MarkerSize',56)
plotSpread({[],[],y2},'distributionMarkers','.','distributionColors','k',...
    'MarkerFaceColor','k','MarkerEdgeColor','k','MarkerSize',56)

xlab = {'No Benefit'; 'Benefit'};

figure(1); hold on
plot([0 4],[median([y1;y2]) median([y1;y2])], 'b--','linewidth',4)
set(gca,'xticklabel','')
set(gca,'fontsize',40) %60 
set(gca,'xtick',[1 3],'xticklabel',xlab(:),'fontsize',36) %16
yticks([median([y1; y2]) [0.1:0.1:0.6]])
xlabel('DOC After 1^{st} IADT Cycle^�','fontsize',42)
xlim([0 4])

set(gcf, 'units','normalized','outerposition',[0 0 0.5 1])

ylabel('Self-Renewal, \bf{p_s}')
print('../../Figures/Fig8/A_ps_BenNoBen','-dpng')
