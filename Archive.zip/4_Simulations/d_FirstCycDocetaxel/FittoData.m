function sol = FittoData(pars,sol,treatInt)

options = odeset('RelTol',1e-8,'AbsTol',1e-8); 
Init = sol.y(:,end); 
pars(9) = 0;

for ii = 2:3
    pars(8) = (1-mod(ii,2));

    solTmp = ode45(@modelBasic,[treatInt(ii-1) treatInt(ii)],Init,options,pars);
    sol.x  = [sol.x solTmp.x(2:end)];
    sol.y  = [sol.y solTmp.y(:,2:end)];

    Init = sol.y(:,end);

end