% function TTP_Scatter

close all

AllPatients = [  1   4   6   7   8  11  12  13  14  15 ...
                16  17  18  19  20  24  25  26  28  29 ...
                30  31  33  36  37  39  40  41  42  44 ...
                48  49  50  52  54  55  58  60  61  62 ...
                63  66  71  73  75  77  78  79  80  81 ...
                84  86  87  88  90  91  93  94  95  96 ...
                97  99 100 101 102 104 105 106 108 109];
Ben    = [  1   8  11   12  13  18  19  20  25  26  36  39  49  50 ...
           55  60  71   73  75  79  90  91  93 102 109];
       
load TTP.mat
DOC_TTP(:,2) = DOC_TTP(:,2)/30;
Bruch_TTP(:,2) = Bruch_TTP(:,2)/30;

%--------------------------------Small ps----------------------------------
patients_smallps = [  6   8  13  14  16  17  18  19  24  29  31  36  37 ...
                     40  41  42  44  58  61  62  66  73  77  81  87  88 ...
                     94  95  96 100 101 104 108 109];
%DOC
y_small = DOC_TTP(patients_smallps,:);
IND = find(y_small(:,3) == 0); y_Resp = y_small(IND,2); %Responsive
y_Resp(find(y_Resp > 120)) = 120;
IND = find(y_small(:,3) == 2); y_Res  = y_small(IND,2); %Resistant

%Bruchovsky
y_small = Bruch_TTP(patients_smallps,:);
IND = find(y_small(:,3) == 0); y2_Resp = y_small(IND,2); %Responsive
y2_Resp(find(y2_Resp > 120)) = 120;
IND = find(y_small(:,3) == 2); y2_Res  = y_small(IND,2); %Resistant

%--------------------------------Large ps----------------------------------
patients_largeps = [  1   4   7  11  12  15  20  25  26  28  30  33  39 ...
                     48  49  50  52  54  55  60  63  71  75  78  79  80 ...
                     84  86  90  91  93  99 102 105 106];
 
%Bruchovsky
Bruch_TTP(25,3) = 0;
y_small = Bruch_TTP(patients_largeps,:);
IND = find(y_small(:,3) == 0); y3_Resp = y_small(IND,2); %Responsive
y3_Resp(find(y3_Resp > 120)) = 120;
IND = find(y_small(:,3) == 2); y3_Res  = y_small(IND,2); %Resistant

%DOC
y_small = DOC_TTP(patients_largeps,:);
IND = find(y_small(:,3) == 0); y4_Resp = y_small(IND,2); %Responsive
y4_Resp(find(y4_Resp > 120)) = 120;
IND = find(y_small(:,3) == 2); y4_Res  = y_small(IND,2); %Resistant

Col = [0.8 1 0.8; 0 1 0; 1 0 0; 1 0.8 0.8];

figure(1); hold on
plotSpread(y_Resp,'distributionMarkers','o','distributionColors',Col(1,:),...
    'MarkerFaceColor','w','MarkerEdgeColor',Col(1,:),'MarkerSize',16)
plotSpread(y_Res,'distributionMarkers','.','distributionColors',Col(1,:),...
    'MarkerFaceColor',Col(1,:),'MarkerEdgeColor',Col(1,:),'MarkerSize',58)

plotSpread({[],[],y2_Resp},'distributionMarkers','o','distributionColors',Col(2,:),...
    'MarkerFaceColor','w','MarkerEdgeColor',Col(2,:),'MarkerSize',16)
plotSpread({[],[],y2_Res},'distributionMarkers','.','distributionColors',Col(2,:),...
    'MarkerFaceColor',Col(2,:),'MarkerEdgeColor',Col(2,:),'MarkerSize',58)

plotSpread({[],[],[],[],y3_Resp},'distributionMarkers','o','distributionColors',Col(3,:),...
    'MarkerFaceColor','w','MarkerEdgeColor',Col(3,:),'MarkerSize',16)
plotSpread({[],[],[],[],y3_Res},'distributionMarkers','.','distributionColors',Col(3,:),...
    'MarkerFaceColor',Col(3,:),'MarkerEdgeColor',Col(3,:),'MarkerSize',58)

plotSpread({[],[],[],[],[],[],y4_Resp},'distributionMarkers','o','distributionColors',Col(4,:),...
    'MarkerFaceColor','w','MarkerEdgeColor',Col(4,:),'MarkerSize',16)
plotSpread({[],[],[],[],[],[],y4_Res},'distributionMarkers','.','distributionColors',Col(4,:),...
    'MarkerFaceColor',Col(4,:),'MarkerEdgeColor',Col(4,:),'MarkerSize',58)

% xlab = {'IADT'; 'IADT'; 'IADT'; 'IADT'};
xlab = {'w/'; 'w/o'; 'w/o'; 'w/'};
xlab = {'DOC^�'; 'DOC^�'; 'DOC^�'; 'DOC^�'};
ylab = {'0'; '12'; '24'; '36'; '48'; '60'; '72'; '84'; '96'; '108'; 'EOS'};

figure(1); hold on
plot([0.5 1.5],[mean(y_Res) mean(y_Res)],'-','Color',Col(1,:),'linewidth',4)
plot([2.5 3.5],[mean(y2_Res) mean(y2_Res)],'-','Color',Col(2,:),'linewidth',4)
plot([4.5 5.5],[mean(y3_Res) mean(y3_Res)],'-','Color',Col(3,:),'linewidth',4)
plot([6.5 7.5],[mean(y4_Res) mean(y4_Res)],'-','Color',Col(4,:),'linewidth',4)
set(gca,'yticklabel','')
set(gca,'ytick',[0:12:120],'yticklabel',ylab(:)) %16
ylim([0 120])
set(gca,'xticklabel','')
set(gca,'xtick',[1 3 5 7],'xticklabel',xlab(:)) %16
set(gca,'fontsize',40) %60 
ylabel('Time to Progression (months)')
xlabel('p_s    med(p_s)    p_s    med(p_s)')
set(gcf, 'units','normalized','outerposition',[0 0 0.55 1])
print('../../Figures/Fig8/C_TTP_Scatter','-dpng')