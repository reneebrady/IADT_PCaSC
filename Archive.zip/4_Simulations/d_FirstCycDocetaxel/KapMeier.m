% function KapMeier

close all

AllPatients = [  1   4   6   7   8  11  12  13  14  15 ...
                16  17  18  19  20  24  25  26  28  29 ...
                30  31  33  36  37  39  40  41  42  44 ...
                48  49  50  52  54  55  58  60  61  62 ...
                63  66  71  73  75  77  78  79  80  81 ...
                84  86  87  88  90  91  93  94  95  96 ...
                97  99 100 101 102 104 105 106 108 109];

Res = zeros(109,1);
Res([7  11  12	19  25  33  36	41	48  52  54	80	88  99 101]) = 2; %Resistant
Res([6   8  16  18  20  42  49  71  73  78  84  94 102 109]) = 1; %Lost to followup

patients = AllPatients;

load TTP.mat
Bruchovsky_TTP = Bruch_TTP(patients,:);
Bruchovsky_TTP(:,2) = Bruchovsky_TTP(:,2)/30;

[~,IND] = sort(Bruchovsky_TTP(:,2),'ascend');
TTP = Bruchovsky_TTP(IND,:);
N = length(TTP);

IND = find(TTP(:,3) > 0); %find where patient was resistant or LTF
KM = TTP(IND,2); KM = unique(KM);
cKM = []; ctime = [];
S = 1;

D1 = TTP(:,2:3);

for i = 1:length(KM)
    RES = length(find(TTP(:,2) == KM(i) & TTP(:,3) == 2)); %find where TTP = day & patient was resistant
    LTF = length(find(TTP(:,2) == KM(i) & TTP(:,3) == 1)); %find where TTP = day & patient was LTF

    if LTF > 0
        cKM = [cKM; S(end)];
        ctime = [ctime; KM(i)];
    end
    
    S = [S; (1 - (RES/N))*S(end)];
    N = N - (RES + LTF);
    
end

dtime = 0;
for i = 1:length(KM)
    dtime = [dtime; KM(i); KM(i)];
end
dtime = [dtime; TTP(end,2)];

S2 = [];
for i = 1:length(S)
    S2 = [S2; S(i); S(i)];
end

figure(1); hold on; 
plot(dtime,S2,'k','linewidth',6)
plot(ctime,cKM,'r+','MarkerSize',12,'linewidth',6)
ylim([0 1])
set(gca,'xtick',0:12:120) %16
ylabel('Progression Free Survival')
xlabel('Time to Progression (months)')
set(gca,'fontsize',36)


load TTP.mat
%----------------------------DOC after 1st cycle---------------------------
SIM_TTP = DOC_TTP(patients,:);
SIM_TTP(:,2) = SIM_TTP(:,2)/30;
[~,IND] = sort(SIM_TTP(:,2),'ascend');
TTP = SIM_TTP(IND,:);
N = length(TTP);

IND = find(TTP(:,3) > 0); %find where patient was resistant or LTF
KM = TTP(IND,2); KM = unique(KM);
cKM = []; ctime = [];
S = 1;

D2 = TTP(:,2:3);

for i = 1:length(KM)
    RES = length(find(TTP(:,2) == KM(i) & TTP(:,3) == 2)); %find where TTP = day & patient was resistant
    LTF = length(find(TTP(:,2) == KM(i) & TTP(:,3) == 1)); %find where TTP = day & patient was LTF

    if LTF > 0
        cKM = [cKM; S(end)];
        ctime = [ctime; KM(i)];
    end
    
    S = [S; (1 - (RES/N))*S(end)];
    N = N - (RES + LTF);
    
end

dtime = 0;
for i = 1:length(KM)
    dtime = [dtime; KM(i); KM(i)];
end
dtime = [dtime; TTP(end,2)];

S2 = [];
for i = 1:length(S)
    S2 = [S2; S(i); S(i)];
end

Col = lines(2); 

figure(1); hold on; 
plot(dtime,S2,'Color',[0.8 0.8 0.8],'linewidth',6) %castration naive (blue)
plot(ctime,cKM,'r+','MarkerSize',12,'linewidth',6)

%------------------------------ps < med(ps)--------------------------------
%-------------------------------Bruchovsky---------------------------------
patients_smallps = [  6   8  13  14  16  17  18  19  24  29  31  36  37 ...
                     40  41  42  44  58  61  62  66  73  77  81  87  88 ...
                     94  95  96 100 101 104 108 109];

load TTP.mat
Bruchovsky_TTP = Bruch_TTP(patients_smallps,:);
Bruchovsky_TTP(:,2) = Bruchovsky_TTP(:,2)/30;

[~,IND] = sort(Bruchovsky_TTP(:,2),'ascend');
TTP = Bruchovsky_TTP(IND,:);
N = length(TTP);

IND = find(TTP(:,3) > 0); %find where patient was resistant or LTF
KM = TTP(IND,2); KM = unique(KM);
cKM = []; ctime = [];
S = 1;

D3 = TTP(:,2:3);

for i = 1:length(KM)
    RES = length(find(TTP(:,2) == KM(i) & TTP(:,3) == 2)); %find where TTP = day & patient was resistant
    LTF = length(find(TTP(:,2) == KM(i) & TTP(:,3) == 1)); %find where TTP = day & patient was LTF

    if LTF > 0
        cKM = [cKM; S(end)];
        ctime = [ctime; KM(i)];
    end
    
    S = [S; (1 - (RES/N))*S(end)];
    N = N - (RES + LTF);
    
end

dtime = 0;
for i = 1:length(KM)
    dtime = [dtime; KM(i); KM(i)];
end
dtime = [dtime; TTP(end,2)];

S2 = [];
for i = 1:length(S)
    S2 = [S2; S(i); S(i)];
end

figure(1); hold on; 
plot(dtime,S2,'g','linewidth',6)
plot(ctime,cKM,'r+','MarkerSize',12,'linewidth',6)

load TTP.mat
%----------------------------DOC after 1st cycle---------------------------
SIM_TTP = DOC_TTP(patients_smallps,:);
SIM_TTP(:,2) = SIM_TTP(:,2)/30;
[~,IND] = sort(SIM_TTP(:,2),'ascend');
TTP = SIM_TTP(IND,:);
N = length(TTP);

IND = find(TTP(:,3) > 0); %find where patient was resistant or LTF
KM = TTP(IND,2); KM = unique(KM);
cKM = []; ctime = [];
S = 1;

D4 = TTP(:,2:3);

for i = 1:length(KM)
    RES = length(find(TTP(:,2) == KM(i) & TTP(:,3) == 2)); %find where TTP = day & patient was resistant
    LTF = length(find(TTP(:,2) == KM(i) & TTP(:,3) == 1)); %find where TTP = day & patient was LTF

    if LTF > 0
        cKM = [cKM; S(end)];
        ctime = [ctime; KM(i)];
    end
    
    S = [S; (1 - (RES/N))*S(end)];
    N = N - (RES + LTF);
    
end

dtime = 0;
for i = 1:length(KM)
    dtime = [dtime; KM(i); KM(i)];
end
dtime = [dtime; TTP(end,2)];

S2 = [];
for i = 1:length(S)
    S2 = [S2; S(i); S(i)];
end

Col = lines(2); 

figure(1); hold on; 
plot(dtime,S2,'Color',[0.8 1 0.8],'linewidth',6) %castration naive (blue)
plot(ctime,cKM,'r+','MarkerSize',12,'linewidth',6)

%------------------------------ps >= med(ps)-------------------------------
%-------------------------------Bruchovsky---------------------------------
patients_largeps = [  1   4   7  11  12  15  20  25  26  28  30  33  39 ...
                     48  49  50  52  54  55  60  63  71  75  78  79  80 ...
                     84  86  90  91  93  99 102 105 106];
            
load TTP.mat
Bruchovsky_TTP = Bruch_TTP(patients_largeps,:);
Bruchovsky_TTP(:,2) = Bruchovsky_TTP(:,2)/30;

[~,IND] = sort(Bruchovsky_TTP(:,2),'ascend');
TTP = Bruchovsky_TTP(IND,:);
N = length(TTP);

IND = find(TTP(:,3) > 0); %find where patient was resistant or LTF
KM = TTP(IND,2); KM = unique(KM);
cKM = []; ctime = [];
S = 1;

D5 = TTP(:,2:3);

for i = 1:length(KM)
    RES = length(find(TTP(:,2) == KM(i) & TTP(:,3) == 2)); %find where TTP = day & patient was resistant
    LTF = length(find(TTP(:,2) == KM(i) & TTP(:,3) == 1)); %find where TTP = day & patient was LTF

    if LTF > 0
        cKM = [cKM; S(end)];
        ctime = [ctime; KM(i)];
    end
    
    S = [S; (1 - (RES/N))*S(end)];
    N = N - (RES + LTF);
    
end

dtime = 0;
for i = 1:length(KM)
    dtime = [dtime; KM(i); KM(i)];
end
dtime = [dtime; TTP(end,2)];

S2 = [];
for i = 1:length(S)
    S2 = [S2; S(i); S(i)];
end

figure(1); hold on; 
plot(dtime,S2,'r','linewidth',6)
plot(ctime,cKM,'r+','MarkerSize',12,'linewidth',6)

load TTP.mat
%----------------------------DOC after 1st cycle---------------------------
SIM_TTP = DOC_TTP(patients_largeps,:);
SIM_TTP(:,2) = SIM_TTP(:,2)/30;
[~,IND] = sort(SIM_TTP(:,2),'ascend');
TTP = SIM_TTP(IND,:);
N = length(TTP);

IND = find(TTP(:,3) > 0); %find where patient was resistant or LTF
KM = TTP(IND,2); KM = unique(KM);
cKM = []; ctime = [];
S = 1;

D6 = TTP(:,2:3);

for i = 1:length(KM)
    RES = length(find(TTP(:,2) == KM(i) & TTP(:,3) == 2)); %find where TTP = day & patient was resistant
    LTF = length(find(TTP(:,2) == KM(i) & TTP(:,3) == 1)); %find where TTP = day & patient was LTF

    if LTF > 0
        cKM = [cKM; S(end)];
        ctime = [ctime; KM(i)];
    end
    
    S = [S; (1 - (RES/N))*S(end)];
    N = N - (RES + LTF);
    
end

dtime = 0;
for i = 1:length(KM)
    dtime = [dtime; KM(i); KM(i)];
end
dtime = [dtime; TTP(end,2)];

S2 = [];
for i = 1:length(S)
    S2 = [S2; S(i); S(i)];
end

Col = lines(2); 

figure(1); hold on; 
plot(dtime,S2,'Color',[1 0.8 0.8],'linewidth',6) %castration naive (blue)
plot(ctime,cKM,'r+','MarkerSize',12,'linewidth',6)

xlim([0 120]); ylim([0 1])
set(gcf, 'units','normalized','outerposition',[0 0 1 1]);
print('../../Figures/Fig8/B_KapMeier','-dpng')

chi_46 = LogRank(D4,D6);
chi_35 = LogRank(D3,D5);
% chi_23 = LogRank(D2,D3);