% close all

load PARS.mat

AllPatients = [  1   4   6   7   8  11  12  13  14  15 ...
    16  17  18  19  20  24  25  26  28  29 ...
    30  31  33  36  37  39  40  41  42  44 ...
    48  49  50  52  54  55  58  60  61  62 ...
    63  66  71  73  75  77  78  79  80  81 ...
    84  86  87  88  90  91  93  94  95  96 ...
    97  99 100 101 102 104 105 106 108 109];

patients = AllPatients;

DOC_TTP = [[1:1:109]' NaN(109,2)]; B_TTP = [[1:1:109]' NaN(109,2)];

for I = patients
    close all
    
    [PSAd,dayd,treatInt] = DataFix(I);
    
    %------------------------Continued Bruchovsky--------------------------
    Init = PARS_0to1(1:4,I); pars = PARS_0to1(5:15,I);
    pars(6) = 0.0027; pars(7) = 0.008;
    
    Init(3) = PSAd(1);
    
    sol.x = treatInt(1); sol.y = Init;
    
    sol = FittoData(pars,sol,treatInt); %fit to first cycle only

    tx = 1;
    
    [sol,flag] = Bruchovsky(sol,pars,tx);
    
    if flag == 1
        B_TTP(I,2:3) = [sol.x(end) 2];
    else
        B_TTP(I,2:3) = [sol.x(end) 0];
    end
    
    %---------------------First Cycle IADT, DOC, IADT----------------------
    Init = PARS_0to1(1:4,I); pars = PARS_0to1(5:15,I);
    pars(6) = 0.0027; pars(7) = 0.008;
    
    Init(3) = PSAd(1);
    
    sol2.x = 0; sol2.y = Init;
    
    sol2 = FittoData(pars,sol2,treatInt(1:4));
    
    Chemo1 = sol2.x(end)/30;
    [sol2,flag] = Chemo(pars,sol2,6);
    Chemo1 = [Chemo1 sol2.x(end)/30];
    
    if flag == 0
        [sol2,flag] = Bruchovsky2(sol2,pars);
    end
    
    if flag == 1
        DOC_TTP(I,2:3) = [sol2.x(end) 2];
    else
        DOC_TTP(I,2:3) = [sol2.x(end) 0];
    end
    
    Col = lines(2);
    
    IND = max(find(dayd <= treatInt(3)));
    
    figure(I); hold on;
    if I == 16 || I == 84
        ylim([0 15])
    end
    plot(dayd(1:IND)/30,PSAd(1:IND),'bx','linewidth',30,'MarkerSize',48)
    plot(sol.x/30,sol.y(3,:),'k-','linewidth',8);
    plot(sol2.x/30,sol2.y(3,:),'-','Color',[0.7 0.7 0.7],'linewidth',8);
    ylabel('PSA (\mug/L)');
        %xlabel('days');
    set(gca,'xtick',0:12:120)
    xlim([0 max([sol.x(end)/30 sol2.x(end)/30])])
    if I < 10
        title(['Patient 00' num2str(I)])
    elseif I < 100
        title(['Patient 0' num2str(I)])
    else
        title(['Patient ' num2str(I)])
    end
    set(gca,'fontsize',60)
    ax = gca;
    fillyy([Chemo1(1) Chemo1(end)],[0 0],[ax.YLim(2) ax.YLim(2)],[0.7 0.7 0.7])
	alpha(0.5)
    set(gcf, 'units','normalized','outerposition',[0 0 1 1]);
    if I == 84 || I == 16
        print(['../../Figures/Fig8/D_FirstCycDOCSim_p' int2str(I)],'-dpng')
    else
        print(['figures/FirstCycDOCSim_p' int2str(I)],'-dpng')
    end
    
    figure(I+100); hold on;
    if I == 16 || I == 84
        ylim([8 108.6086])
    end
    plot(sol.x/30,sol.y(1,:),'k-','linewidth',8);
    plot(sol2.x/30,sol2.y(1,:),'-','Color',[0.7 0.7 0.7],'linewidth',8);
    set(gca,'xtick',0:12:120)
    xlim([0 max([sol.x(end)/30 sol2.x(end)/30])])
    ylabel('PCaSC');
    xlabel('months');
    set(gca,'fontsize',60)
    ax = gca;
    if I == 16 || I == 84
        fillyy([Chemo1(1) Chemo1(end)],[8 8],[ax.YLim(2) ax.YLim(2)],[0.7 0.7 0.7])
    else
        fillyy([Chemo1(1) Chemo1(end)],[0 0],[ax.YLim(2) ax.YLim(2)],[0.7 0.7 0.7])
    end
	alpha(0.5)
    set(gca,'YScale','log')
%     if I == 12 || I == 24 || I == 36
%         ylim([1 1e4])
%     end
%     if I == 12
%         xlim([0 1372])
%     elseif I == 24
%         xlim([0 3650])
%     end
    set(gcf, 'units','normalized','outerposition',[0 0 1 0.75]);
    if I == 84 || I == 16
        print(['../../Figures/Fig8/D_FirstCycDOCSim_p' int2str(I) '_CSC'],'-dpng')
    else
        print(['figures/FirstCycDOCSim_p' int2str(I) '_CSC'],'-dpng')
    end
end

% save TTP.mat Bruch_TTP DOC_TTP
