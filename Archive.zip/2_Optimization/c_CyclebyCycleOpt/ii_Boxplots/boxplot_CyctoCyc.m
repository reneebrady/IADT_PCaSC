function [y1_Resp,y1_Res, y2_Resp, y2_Res, y3_Resp, y3_Res, y4_Resp, y4_Res] = boxplot_CyctoCyc(parnum)

close all

%Load parameters
load PARS.mat

%Cycle 1
Resp = [ 11  12  13	 16	 20	 25  26	 28	 29	 30	 36  39	 41  42	 44	 49	...
         52  55	 58	 61	 62  63  71	 73	 75	 77	 80  84	 87 101 102	104	...
        105	106	109];
Res  = [];
y1_Resp = PARS_0to1(parnum,Resp); %Responsive
y1_Res  = PARS_0to1(parnum,Res);  %Resistant   
y1_Resp = y1_Resp(find(y1_Resp ~= 0)); y1_Res = y1_Res(find(y1_Res ~= 0));

%Cycle 2
Resp = [ 11  12  13	 16	 20	 25  26	 28	 29	 30	 36  39	 42	 44	 49	...
         52  55	 58	 61	 62  63  71	 73	 75	 77	 84	 87 101 102	104	...
        105	106	109];
Res  = [ 41 80];
y2_Resp = PARS_1to2(parnum,Resp); %Responsive
y2_Res  = PARS_1to2(parnum,Res);  %Resistant  
y2_Resp = y2_Resp(find(y2_Resp ~= 0)); y2_Res = y2_Res(find(y2_Res ~= 0));

%Cycle 3
Resp = [ 11  13	 16	 20	 26	 28	 29	 30	 36  39	 42	 44	 49	...
         55	 58	 61	 62  63  71	 73	 75	 77	 84	 87 101 102	104	...
        105	106	109];
Res  = [ 12  25  52];
y3_Resp = PARS_2to3(parnum,Resp); %Responsive
y3_Res  = PARS_2to3(parnum,Res);  %Resistant   
y3_Resp = y3_Resp(find(y3_Resp ~= 0)); y3_Res = y3_Res(find(y3_Res ~= 0));

%Cycle 4
Resp = [ 11  13	 16	 20	 26	 28	 29	 30	 39	 42	 44	 49	...
         55	 58	 61	 62  63  71	 73	 75	 77	 84	 87 104	...
        105	106	109];
Res  = [ 36 101 102];
y4_Resp = PARS_3to4(parnum,Resp); %Responsive
y4_Res  = PARS_3to4(parnum,Res);  %Resistant   
y4_Resp = y4_Resp(find(y4_Resp ~= 0)); y4_Res = y4_Res(find(y4_Res ~= 0));

y1 = [y1_Resp y1_Res];
ii = -1;
N = size(y1,2);
if (isempty(y1) || length(y1)<3)
    ii = ii + 2;
    h(2) = plot(0,0,'r-');
    COV(2) = NaN;
else
    for i = 1:size(y1,1)
        ii = ii + 2;
        x = sort(y1(i,:));

        COV(2) = std(x)/mean(x)*100;

        Q2 = median(x);

        I  = 0.25*(N+1);
        II = floor(I);
        if I - II == 0
            Q1 = x(II);
        else
            Q1 = x(II) + (I - II)*(x(II+1)-x(II));
        end

        I  = 0.75*(N+1);
        II = floor(I);
        if I - II == 0
            Q3 = x(II);
        else
            Q3 = x(II) + (I - II)*(x(II+1)-x(II));
        end
    
        IQR = Q3 - Q1;

        UIF = Q3 + 1.5*IQR;
        LIF = Q1 - 1.5*IQR;

        UIF = min(UIF,max(x));   
        LIF = max(LIF,min(x));

        figure(1); hold on
        h = plot([ii-0.5 ii+0.5],[Q2 Q2],'Color',[0.25 0.25 0.25],'linewidth',6);
        h = rectangle('Position',[ii-0.5 Q1 1 IQR],'EdgeColor',[0.25 0.25 0.25],'linewidth',6);
        h = plot([ii ii],[Q3 UIF],'--','Color',[0.25 0.25 0.25],'linewidth',6);
        h = plot([ii-0.5 ii+0.5],[UIF UIF],'Color',[0.25 0.25 0.25],'linewidth',6);
        h = plot([ii ii],[Q1 LIF],'--','Color',[0.25 0.25 0.25],'linewidth',6);
        h = plot([ii-0.5 ii+0.5],[LIF LIF],'Color',[0.25 0.25 0.25],'linewidth',6);
    end
end

y2 = [y2_Resp y2_Res];
N = size(y2,2);
if (isempty(y2) || length(y2)<3)
    ii = ii + 2;
    h(2) = plot(0,0,'r-');
    COV(2) = NaN;
else
    for i = 1:size(y2,1)
        ii = ii + 2;
        x = sort(y2(i,:));

        COV(2) = std(x)/mean(x)*100;

        Q2 = median(x);

        I  = 0.25*(N+1);
        II = floor(I);
        if I - II == 0
            Q1 = x(II);
        else
            Q1 = x(II) + (I - II)*(x(II+1)-x(II));
        end

        I  = 0.75*(N+1);
        II = floor(I);
        if I - II == 0
            Q3 = x(II);
        else
            Q3 = x(II) + (I - II)*(x(II+1)-x(II));
        end
    
        IQR = Q3 - Q1;

        UIF = Q3 + 1.5*IQR;
        LIF = Q1 - 1.5*IQR;

        UIF = min(UIF,max(x));   
        LIF = max(LIF,min(x));

        figure(1); hold on
        h = plot([ii-0.5 ii+0.5],[Q2 Q2],'Color',[0.25 0.25 0.25],'linewidth',6);
        h = rectangle('Position',[ii-0.5 Q1 1 IQR],'EdgeColor',[0.25 0.25 0.25],'linewidth',6);
        h = plot([ii ii],[Q3 UIF],'--','Color',[0.25 0.25 0.25],'linewidth',6);
        h = plot([ii-0.5 ii+0.5],[UIF UIF],'Color',[0.25 0.25 0.25],'linewidth',6);
        h = plot([ii ii],[Q1 LIF],'--','Color',[0.25 0.25 0.25],'linewidth',6);
        h = plot([ii-0.5 ii+0.5],[LIF LIF],'Color',[0.25 0.25 0.25],'linewidth',6);
    end
end

y3 = [y3_Resp y3_Res];
N = size(y3,2);
if (isempty(y3) || length(y3)<3)
    ii = ii + 2;
    h(2) = plot(0,0,'r-');
    COV(2) = NaN;
else
    for i = 1:size(y3,1)
        ii = ii + 2;
        x = sort(y3(i,:));

        COV(2) = std(x)/mean(x)*100;

        Q2 = median(x);

        I  = 0.25*(N+1);
        II = floor(I);
        if I - II == 0
            Q1 = x(II);
        else
            Q1 = x(II) + (I - II)*(x(II+1)-x(II));
        end

        I  = 0.75*(N+1);
        II = floor(I);
        if I - II == 0
            Q3 = x(II);
        else
            Q3 = x(II) + (I - II)*(x(II+1)-x(II));
        end
    
        IQR = Q3 - Q1;

        UIF = Q3 + 1.5*IQR;
        LIF = Q1 - 1.5*IQR;

        UIF = min(UIF,max(x));   
        LIF = max(LIF,min(x));

        figure(1); hold on
        h = plot([ii-0.5 ii+0.5],[Q2 Q2],'Color',[0.25 0.25 0.25],'linewidth',6);
        h = rectangle('Position',[ii-0.5 Q1 1 IQR],'EdgeColor',[0.25 0.25 0.25],'linewidth',6);
        h = plot([ii ii],[Q3 UIF],'--','Color',[0.25 0.25 0.25],'linewidth',6);
        h = plot([ii-0.5 ii+0.5],[UIF UIF],'Color',[0.25 0.25 0.25],'linewidth',6);
        h = plot([ii ii],[Q1 LIF],'--','Color',[0.25 0.25 0.25],'linewidth',6);
        h = plot([ii-0.5 ii+0.5],[LIF LIF],'Color',[0.25 0.25 0.25],'linewidth',6);
    end
end

y4 = [y4_Resp y4_Res];
N = size(y4,2);
if (isempty(y4) || length(y4)<3)
    ii = ii + 2;
    h(2) = plot(0,0,'r-');
    COV(2) = NaN;
else
    for i = 1:size(y4,1)
        ii = ii + 2;
        x = sort(y4(i,:));

        COV(2) = std(x)/mean(x)*100;

        Q2 = median(x);

        I  = 0.25*(N+1);
        II = floor(I);
        if I - II == 0
            Q1 = x(II);
        else
            Q1 = x(II) + (I - II)*(x(II+1)-x(II));
        end

        I  = 0.75*(N+1);
        II = floor(I);
        if I - II == 0
            Q3 = x(II);
        else
            Q3 = x(II) + (I - II)*(x(II+1)-x(II));
        end
    
        IQR = Q3 - Q1;

        UIF = Q3 + 1.5*IQR;
        LIF = Q1 - 1.5*IQR;

        UIF = min(UIF,max(x));   
        LIF = max(LIF,min(x));

        figure(1); hold on
        h = plot([ii-0.5 ii+0.5],[Q2 Q2],'Color',[0.25 0.25 0.25],'linewidth',6);
        h = rectangle('Position',[ii-0.5 Q1 1 IQR],'EdgeColor',[0.25 0.25 0.25],'linewidth',6);
        h = plot([ii ii],[Q3 UIF],'--','Color',[0.25 0.25 0.25],'linewidth',6);
        h = plot([ii-0.5 ii+0.5],[UIF UIF],'Color',[0.25 0.25 0.25],'linewidth',6);
        h = plot([ii ii],[Q1 LIF],'--','Color',[0.25 0.25 0.25],'linewidth',6);
        h = plot([ii-0.5 ii+0.5],[LIF LIF],'Color',[0.25 0.25 0.25],'linewidth',6);
    end
end

y1 = y1'; y2 = y2'; y3 = y3'; y4 = y4';

Col = lines(2);

plotSpread(y1_Resp','distributionMarkers','.','distributionColors',Col(1,:),...
    'MarkerFaceColor',Col(1,:),'MarkerEdgeColor',Col(1,:),'MarkerSize',48)
plotSpread(y1_Res','distributionMarkers','^','distributionColors',Col(2,:),...
    'MarkerFaceColor',Col(2,:),'MarkerEdgeColor',Col(2,:),'MarkerSize',24)
plotSpread({[],[],y2_Resp'},'distributionMarkers','.','distributionColors',Col(1,:),...
    'MarkerFaceColor',Col(1,:),'MarkerEdgeColor',Col(1,:),'MarkerSize',48)
plotSpread({[],[],y2_Res'},'distributionMarkers','^','distributionColors',Col(2,:),...
    'MarkerFaceColor',Col(2,:),'MarkerEdgeColor',Col(2,:),'MarkerSize',24)
plotSpread({[],[],[],[],y3_Resp'},'distributionMarkers','.','distributionColors',Col(1,:),...
    'MarkerFaceColor',Col(1,:),'MarkerEdgeColor',Col(1,:),'MarkerSize',48)
plotSpread({[],[],[],[],y3_Res'},'distributionMarkers','^','distributionColors',Col(2,:),...
    'MarkerFaceColor',Col(2,:),'MarkerEdgeColor',Col(2,:),'MarkerSize',24)
plotSpread({[],[],[],[],[],[],y4_Resp'},'distributionMarkers','.','distributionColors',Col(1,:),...
    'MarkerFaceColor',Col(1,:),'MarkerEdgeColor',Col(1,:),'MarkerSize',48)
plotSpread({[],[],[],[],[],[],y4_Res'},'distributionMarkers','^','distributionColors',Col(2,:),...
    'MarkerFaceColor',Col(2,:),'MarkerEdgeColor',Col(2,:),'MarkerSize',24)

xlab = {'Cycle 1'; 'Cycle 2'; 'Cycle 3'; 'Cycle 4'};

figure(1); hold on
% set(gcf, 'units','normalized','outerposition',[0 0 0.5 1]); %[0 0 1 1]
set(gca,'xticklabel','')
set(gca,'xtick',[1 3 5 7],'xticklabel',xlab(:),'fontsize',8) %16
set(gca,'fontsize',60) %60 
xlim([0 8])

set(gcf, 'units','normalized','outerposition',[0 0 1 1])

if parnum == 5
    ylabel('Self-Renewal, \bf{p_s}')
    grid on
    print('../../../Figures/Fig2/A_ps_CycbyCycboxplot','-dpng')
elseif parnum == 9
    ylabel('ADT Cytotoxicity, \bf{\alpha}')
    grid on
elseif parnum == 14
    ylabel({'$\varphi$'},'Interpreter','latex')
    grid on
elseif parnum == 15
    ylabel('\bf{\rho}')
    grid on
end
y1_Resp = y1_Resp'; y1_Res = y1_Res'; y2_Resp = y2_Resp'; y2_Res = y2_Res'; 
y3_Resp = y3_Resp'; y3_Res = y3_Res'; y4_Resp = y4_Resp'; y4_Res = y4_Res';