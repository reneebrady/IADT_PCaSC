%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                           SOLUTION FUNCTION
%Solves system and computes error
%Inputs -  pars: current parameter values
%          data: data for model comparison
%          Init: initial conditions
%Outputs - err:  error = model - data
%          sol:  model solution
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [err,sol] = model_sol(pars,Init,data)

sol.x = data.treatInt(1); sol.y = Init;

options = odeset('RelTol',1e-8,'AbsTol',1e-8); 

err = []; k = 1;
for ii = 2:length(data.treatInt)
    pars(8) = (1-mod(ii,2));

    solTmp = ode45(@modelBasic,[data.treatInt(ii-1) data.treatInt(ii)],Init,options,pars);
    sol.x  = [sol.x solTmp.x(2:end)];
    sol.y  = [sol.y solTmp.y(:,2:end)];

    Init = sol.y(:,end);

end

PSAm = interp1(sol.x,sol.y(3,:),data.day);

err = (PSAm(2:end) - data.PSA(2:end))/mean(data.PSA(2:end));
err = err(~isnan(err));
