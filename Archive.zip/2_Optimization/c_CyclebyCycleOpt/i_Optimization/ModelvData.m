% function ModelvData

close all 

AllPatients = [  1   4   6   7   8  11  12  13  14  15 ...
                16  17  18  19  20  24  25  26  28  29 ...
                30  31  33  36  37  39  40  41  42  44 ...
                48  49  50  52  54  55  58  60  61  62 ...
                63  66  71  73  75  77  78  79  80  81 ...
                84  86  87  88  90  91  93  94  95  96 ...
                97  99 100 101 102 104 105 106 108 109];

% %Training
% Resp = [ 4	 8	13	18	20	30	37	 42	 44	 49	 50	55	58	60	61	63 ...
%         78	81	86	87	90	94	95	105	106	109];
% Res  = [7	19	25	41	54	88	99	101	102];

%Testing
Resp = [ 1	 6	14	15	16	17	24	26	28	 29	 31	 39	40	62	66	71 ...
        73	75	77	79	84	91	93	96	97	100	104	108]; %exclude 1 maybe
Res  = [11	12	33	36	48	52	80];
    
patients = [Resp Res];

[M,D] = PlotResults(patients);

x = 0:35;
figure(100); hold on
scatter(D,M,150,'filled','b')
plot(x,x,'k','linewidth',4)
xlabel('Measured PSA')
ylabel('Simulated PSA')
set(gca,'fontsize',55) 
set(gcf, 'units','normalized','outerposition',[0 0 0.5 1])
% xlim([0 50]); ylim([0 50])
% print('AllPats_MvD','-dpng')
% print('TrainPats_MvD','-dpng')
print('TestPats_MvD','-dpng')

IND = find(~isnan(M)); D = D(IND); M = M(IND);
SSR = (M-D)/mean(D);
SST = (D - mean(D))/mean(D);

R2 = 1 - (SSR'*SSR)/(SST'*SST);

mdl = fitlm(M,D);
R2_2 = mdl.Rsquared.Ordinary;